package practicacalificada;
import java.util.Scanner;

public class Factura extends Documento{
    
}
