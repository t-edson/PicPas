package practicacalificada;

public class Boleta extends Documento {

}
