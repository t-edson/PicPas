package practicacalificada;
import java.util.Scanner;

public class PracticaCalificada {
    public static void main(String[] args) {
        
        System.out.println("Ingrese documento a usar:"  );
     
            Scanner teclado = new Scanner(System.in);
        
        
        Boleta b = new Boleta() ;
        Factura f = new Factura();
        
        
 }    
    
}
