package practicacalificada;

public abstract class Documento {
    public int idProduct;
    private String descripcion;
    public  double precio=15;
    int descuento;
     
  public void Imprimir(){
    System.out.println("Este es un documento ");
    }
 
    }


 
     