package practnota;
import java.util.Scanner;

public class PractNota {

    public static void main(String[] args) {
    int num =5;
    int x=1;
    int sumat=0;
    double promedio = sumat/5;
    
    while (num>=x)
    {Scanner scan=new Scanner(System.in);
     System.out.println("Ingrese Nota " +  x);
     sumat=scan.nextInt()+ sumat;
     x++;  
    }
    System.out.println("Total Sumatoria de Notas " + sumat);
    System.out.println("Promedio de Notas es  " + promedio);
    
}
}

    
