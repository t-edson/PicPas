/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boleta_factura;

import java.util.Scanner;

/**
 *
 * @author JAVA-FUN-DEV
 */
public class Boleta_Factura {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Producto _Producto = new Producto();
        _Producto.mGuardarProducto();
        System.out.println("Desea Boleta o Factura");
        System.out.println("1) BOLETA");
        System.out.println("2) FACTURA");
        
        int opcion = 0;
        Scanner scanner = new Scanner(System.in);
        opcion = scanner.nextInt();
        Boleta _Boleta = new Boleta();
        Factura _Factura = new Factura();
        TipoDocumento _TipoDocumento = new TipoDocumento();
        if(opcion == 1 || opcion == 2){
            if(opcion == 1){
                _Boleta.mGuardarBoleta();
                System.out.println("CODIGO DE BOLETA " + _Boleta.getCodigo_boleta());
            }else if(opcion == 2){
                _Factura.mGuardarFactura();
                System.out.println("CODIGO DE FACTURA " + _Factura.getCodigo_Factura());
            }
            _TipoDocumento.mGuardarTipoDocumento();
            System.out.println("DETALLE DEL PRODUCTO********** " + "NOMBRE: " + _Producto.getNombre_Producto() + " PRECIO: " + _Producto.getPrecio_producto());
            System.out.println("FECHA EMITIDA DEL COMPROBANTE " + _TipoDocumento.getFecha());
        }
        
    }
    
}
