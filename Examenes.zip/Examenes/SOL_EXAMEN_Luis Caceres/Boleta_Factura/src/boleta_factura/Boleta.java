/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boleta_factura;

/**
 *
 * @author JAVA-FUN-DEV
 */
public class Boleta extends TipoDocumento{
    public String codigo_boleta;

    public Boleta(){}
    
    public Boleta(String codigo_boleta){
        this.codigo_boleta = codigo_boleta;
    }
    
    public String getCodigo_boleta() {
        return codigo_boleta;
    }

    public void setCodigo_boleta(String codigo_boleta) {
        this.codigo_boleta = codigo_boleta;
    }   
    
    public void mGuardarBoleta(){
        codigo_boleta = "COD_BOL_001";
    }
    
}
