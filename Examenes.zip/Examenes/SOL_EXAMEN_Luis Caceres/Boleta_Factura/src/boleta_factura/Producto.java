/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boleta_factura;

/**
 *
 * @author JAVA-FUN-DEV
 */
public class Producto {
    public String codigo_Producto;
    public String nombre_Producto;
    public double precio_producto;
    
    public Producto(){}
    
    public Producto(String codigo_Producto, String nombre_Producto, double precio_producto){
        this.codigo_Producto = codigo_Producto;
        this.nombre_Producto = nombre_Producto;
        this.precio_producto = precio_producto;
    }

    public String getCodigo_Producto() {
        return codigo_Producto;
    }

    public void setCodigo_Producto(String codigo_Producto) {
        this.codigo_Producto = codigo_Producto;
    }

    public String getNombre_Producto() {
        return nombre_Producto;
    }

    public void setNombre_Producto(String nombre_Producto) {
        this.nombre_Producto = nombre_Producto;
    }

    public double getPrecio_producto() {
        return precio_producto;
    }

    public void setPrecio_producto(double precio_producto) {
        this.precio_producto = precio_producto;
    }
    
    public void mGuardarProducto(){
        codigo_Producto = "COD_001";
        nombre_Producto = "LAPTOP";
        precio_producto = 1000.0;
    }
    
}
