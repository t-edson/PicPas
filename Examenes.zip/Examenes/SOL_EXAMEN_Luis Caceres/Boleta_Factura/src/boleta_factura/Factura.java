/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boleta_factura;

/**
 *
 * @author JAVA-FUN-DEV
 */
public class Factura extends TipoDocumento{
    public String codigo_Factura;

    public Factura(){}
    
    public Factura(String codigo_Factura){
    this.codigo_Factura = codigo_Factura;
    }
    
    public String getCodigo_Factura() {
        return codigo_Factura;
    }

    public void setCodigo_Factura(String codigo_Factura) {
        this.codigo_Factura = codigo_Factura;
    }
    
    public void mGuardarFactura(){
        codigo_Factura = "COD_FAC_001";
    }
    
    
}
