/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package boleta_factura;

/**
 *
 * @author JAVA-FUN-DEV
 */
public class TipoDocumento {
    public String fecha;

    public TipoDocumento(){
    }
    
    public TipoDocumento(String fecha){
        this.fecha = fecha;
    }
    
    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    
    public void mGuardarTipoDocumento(){
        fecha = "11/05/2019";
    }
}
