/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programa_examen_03;

import java.util.Scanner;

/**
 *
 * @author JAVA-FUN-DEV
 */
public class Programa_examen_03 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("*********************************************************************");
        System.out.println("*****OBTENGA EL PROMEDIO DE N NOTAS UTILICE SENTENCIAS DE CONTROL****");
        System.out.println("*********************************************************************");
        
        int n_notas = 0;
        double nota = 0, acum_notas = 0, promedio = 0;
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese cuantas notas desea promediar:");
        try{
            n_notas = scanner.nextInt();

            for(int i = 1; i <= n_notas; i++){
                System.out.println("Ingrese nota: #" + i);
                nota = scanner.nextInt();
                acum_notas += nota;
            }
            promedio = acum_notas / n_notas;
            System.out.println("Suma total de las notas ingresadas: " + acum_notas);        
            System.out.println("Promedio final de " + n_notas + " notas ingresadas es: " + promedio);

            if(promedio >= 11 && promedio <= 20){
                System.out.println("*****FELICIDADES ALUMNO APROBADO*****");
            }else if(promedio >=0 && promedio <=10){
                System.err.println("*****ALUMNO DESAPROBADO*****");
            }
        }catch(Exception ex){ System.err.println("INGRESE SOLO NUMEROS");}
    }
    
}
