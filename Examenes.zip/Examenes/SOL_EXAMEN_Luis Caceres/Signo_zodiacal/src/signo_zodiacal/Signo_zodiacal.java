/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package signo_zodiacal;

import java.util.Scanner;

/**
 *
 * @author JAVA-FUN-DEV
 */
public class Signo_zodiacal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int mes = 0, dia = 0, anio = 0;
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese dia de Nacimiento");
        dia = scanner.nextInt();
        System.out.println("Ingrese dia de Mes");        
        
        mes = scanner.nextInt();
        String signo = "";
        switch(mes){
            case 1: signo = "Tauro";
            break;
            case 2: signo = "Cancer";
            break;
            case 3: signo = "Geminis";
            break;
            default: signo = "otros";
            break;
        }
        
        System.out.println("Ingrese dia de Año");
        anio = scanner.nextInt();
        
        System.out.println("Su signo es " + signo);
    }
    
}
