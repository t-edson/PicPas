
package prob4;


public class Precio {
    private int cant;
    private double precioUnitario;

    public Precio(int cant, double precioUnitario) {
        this.cant = cant;
        this.precioUnitario = precioUnitario;
    }

    public int getCant() {
        return cant;
    }

    public void setCant(int cant) {
        this.cant = cant;
    }

    public double getPrecioUnitario() {
        return precioUnitario;
    }

    public void setPrecioUnitario(double precioUnitario) {
        this.precioUnitario = precioUnitario;
    }
    
    public double total(){
        return cant*precioUnitario;
    }
    
    
}
