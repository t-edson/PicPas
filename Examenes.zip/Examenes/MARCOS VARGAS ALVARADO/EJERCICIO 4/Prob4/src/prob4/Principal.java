
package prob4;
public class Principal {

    public static void main(String[] args) {
        
     Factura f = new Factura(5,10.20);
     f.cliente = 12345;
     f.total();
     f.imprimirFactura();
 

       
    }    
}
