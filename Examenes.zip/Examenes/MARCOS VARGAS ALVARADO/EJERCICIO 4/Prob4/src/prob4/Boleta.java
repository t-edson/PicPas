
package prob4;
public class Boleta extends Precio {
    
    public Boleta(int cant, double precioUnitario) {
        super(cant, precioUnitario);
        
    }  
}
