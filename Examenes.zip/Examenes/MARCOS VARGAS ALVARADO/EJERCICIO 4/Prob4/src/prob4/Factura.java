
package prob4;

public class Factura extends Precio {
    String emisor;
    
    public int cliente;

    public Factura(int cant, double precioUnitario) {
        super(cant, precioUnitario);
    }

 public void imprimirFactura () {
 System.out.println("");
 System.out.println("Emisor: " + emisor);
 System.out.println("----------------------");
 System.out.println("Cliente: " + cliente);
 System.out.println("Total: " + super.total() + " euros");
 }

    
}
