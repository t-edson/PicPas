
package constructores;

public class constructoress {
   public class Constructores
{
    private String nombre;
    private double precio;

    public String getNombre()
    {
        return nombre;
        
        
    }
    public double getPrecio()
    {
        return precio;
    }

    public void setNombre(String n)
    {
        nombre = n;
    }

    public void setPrecio(double p)
    {
        precio = p;
    }
}
    
    
}
