
package constructores;

public class Constructores {

    public static void main(String[] args) {
         
    
        String nombre ;
        String Precio;
        System.out.println("Ingrese el nombre requerido");
        System.out.println("Ingrse Precio del producto");
    
   }    
}
