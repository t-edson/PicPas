
package promedionotas;
import java.util.Scanner;

public class Entrada {
     //Metodo privado de la clase Scanner para leer entrada de datos por teclado
    private static Scanner Lector = new Scanner(System.in);
    
    //Metodo publico para leer datos Boolean
    public static boolean leerBolean(){
        return Lector.nextBoolean();//devuelve un boolean
    }
    //Metodo publico para leer datos Enteros
    public static int leerEntero(){
        return Lector.nextInt();   
    }
    //Metodo publico para leer datos Double
    public static double LeerDouble(){
        return Lector.nextDouble();    
    }
    //Metodo publico para leer datos Cadenas
    public static String leerCadena(){
        return Lector.nextLine();
    }
    //Metodo publico para leer datos de 1 caracter
    public static char leerCaracter(){
        return Lector.nextLine().charAt(0); 
    
    
    
    }
    
}
