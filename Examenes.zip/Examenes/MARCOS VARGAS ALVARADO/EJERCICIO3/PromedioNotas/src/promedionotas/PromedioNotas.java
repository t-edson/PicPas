
package promedionotas;


public class PromedioNotas {

    public static void main(String[] args) {
     
        // Declaración de atributos/variables
        int notaAlumno1, notaAlumno2, notaAlumno3;
        double nota_total, promedio_notas;      
        boolean rpta;
        
        //Asignación de valores a las variables
        notaAlumno1 = 0;
        notaAlumno2 = 0;
        notaAlumno3 = 0;
        nota_total = 0;
        promedio_notas = 0;
        rpta = true;
        
        //Imprimir, solicitar edad del alumno1
        System.out.print("Ingresa la nota del Alumno 1: ");
        notaAlumno1 = Entrada.leerEntero(); //Lector de dato entero y se gurda la edad del alumno1
        
        //Imprimir, solicitar edad del alumno2
        System.out.print("Ingresa la nota del Alumno 2: ");
        notaAlumno2 = Entrada.leerEntero(); //Lector de dato entero y se gurda la edad del alumno2
        
        //Imprimir, solicitar edad del alumno3
        System.out.print("Ingresa la nota del Alumno 3: ");
        notaAlumno3 = Entrada.leerEntero(); //Lector de dato entero y se gurda la edad del alumno3
        
        //Se calcula el TOTAL de edades
        nota_total = notaAlumno1 + notaAlumno2 + notaAlumno3;
        
        //Se calcula el PROMEDIO de edades
        promedio_notas = nota_total/3;
        
        //Imprimir 
        System.out.println("La SUMA total de  notas es: " + nota_total);
        System.out.println("El PROMEDIO de notas es: " + promedio_notas); 
        System.out.print("¿Dedea aplicar redondeo a PROMEDIO? ");
        rpta = Entrada.leerBolean(); //Lector de datos boolean
        
        if(rpta == true){        
            System.out.println("El promedio de notas REDONDEADO es: " + Math.round(promedio_notas)); //Promedio redondeado
            
        }else{
            System.out.println("El promedio de notas ENTERO es: " + (int)promedio_notas); //Promedio entero
        }
        
        
        
        
        
        
    }
    
}
