
package ptob7;

import java.util.InputMismatchException;
import java.util.Scanner;


public class Promedio {

    
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        double suma=0;
        System.out.println("ingrese la cantidad de numero: ");
        int n=sc.nextInt();
        for (int i = 0; i < n; i++) {
            System.out.println("ingrese numero "+(i+1));
            
            try{
             double numero=sc.nextDouble();    
            suma= suma+numero;
            
                
            }catch(Exception e){
                System.out.println("error usted ingresó un carcater"); 
                break;
            }
        }
        double prom=suma/n;
        
        System.out.println("promedio: "+prom);
       
       
    }
    
}
