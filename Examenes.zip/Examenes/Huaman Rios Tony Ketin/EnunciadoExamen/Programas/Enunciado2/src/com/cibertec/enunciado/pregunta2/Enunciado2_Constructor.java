
package com.cibertec.enunciado.pregunta2;

public class Enunciado2_Constructor {
    
    
    private Integer val1;
    private Integer val2;
    private Integer val3;
    private String str1;
    
    Enunciado2_Constructor(Integer val1,Integer val2, Integer val3, String str1){
        this.val1 = val1;
        this.val2 = val2;
        this.val3 = val3;
        this.str1 = str1;
    }
    
    //Constructor por defecto, no es necesario creardo debido a que java ya lo crea predefinidamente
    Enunciado2_Constructor(){
        
    }
    
    
}
