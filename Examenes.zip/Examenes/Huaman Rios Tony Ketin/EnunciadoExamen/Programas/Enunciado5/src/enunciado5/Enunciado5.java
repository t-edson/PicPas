
package enunciado5;

import javax.swing.JOptionPane;

public class Enunciado5 {

    public static void main(String[] args) {
        
        String dia = JOptionPane.showInputDialog("Ingrese dia de Nacimiento");
        
        String mes = (String) JOptionPane.showInputDialog(null, "Que Mes de nacimiento",
                                    "Seleccione el Mes", JOptionPane.QUESTION_MESSAGE, null, 
                                    new Object[]{"Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"}, "Enero");
        
        String anio = JOptionPane.showInputDialog("Ingrese su año de nacimiento");
        
        String signo = null;
        
        switch(mes){
            case "Enero": signo = "Acuario";
                break;
            case "Febrero": signo = "Piscis";
                break;
            case "Marzo": signo = "Aries";
                break;
            case "Abril": signo = "Tauro";
                break;
            case "Mayo": signo = "Geminis";
                break;
            case "Junio": signo = "Cancer";
                break;
            case "Julio": signo = "Leo";
                break;
            case "Agosto": signo = "Virgo";
                break;
            case "Septiembre": signo = "Libra";
                break;
            case "Octubre": signo = "Escorpio";
                break;
            case "Noviembre": signo = "Sagitario";
                break;
            case "Diciembre": signo = "Capricornio";
                break;
        }
        
        JOptionPane.showMessageDialog(null, "Su signo zodiacal es: " + signo);
        
        
    }
    
}
