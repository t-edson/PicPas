
package com.cibertec.enunciado.pregunta3;

import javax.swing.JOptionPane;

public class ExecutionService {
    
    public static void main(String[] args) {
        
        ExecutionService es = new ExecutionService();
        
        es.startService();
        
    }
    
    private void startService(){
        
        double nota;
        double sumaNota = 0.0;
        boolean newNota = true;
        int count = 1;
        double promedioNotas =0.0;
        
        do{
            try{
                nota = Double.parseDouble(JOptionPane.showInputDialog(null,"Ingrese la nota del alumno"));
                
                sumaNota += nota;
            
                promedioNotas = sumaNota/count;

                count++;
                
                JOptionPane.showMessageDialog(null, "El promedio de notas es: " + promedioNotas);
                
            }catch(Exception e){
                JOptionPane.showMessageDialog(null, "Ingrese solo números");
            }
            
            newNota = this.valdacionAgregarOtraNota();
            
        }while(newNota);
        
        JOptionPane.showMessageDialog(null, "Gracias por ingresar las Notas al Programa");
        
    }
    
    private boolean valdacionAgregarOtraNota(){
        
        int  confirm =   JOptionPane.showConfirmDialog(null, "¿Desea Agregar otra nota?");
        
        if(confirm != 0){
            return false;
        }
        
        return true;
    }
    
}
