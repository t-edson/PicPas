
package com.cibertec.enunciado.pregunta4;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class VentaService {
    
    public void startVenta(){
        
        
        
        boolean newCompra;
        PersonaDto persona = new PersonaDto();
        DocumentoDto docHerencia = new DocumentoDto();
        List<DocumentoDto> doc = new ArrayList<>();
        
        
        persona.setNombres(JOptionPane.showInputDialog("Ingrese el nombre del cliente"));
        persona.setApellido(JOptionPane.showInputDialog("Ingrese los apellidos del cliente"));
        
        persona.setTipoDocumento((String) JOptionPane.showInputDialog(null, "Elija Ahora",
                                    "Seleccione la Tipo Documento", JOptionPane.QUESTION_MESSAGE, null, 
                                    new Object[]{"DNI","CarnetExtranjeria"}, "DNI"));
        
        
        do{
            
            DocumentoDto documento = new DocumentoDto();
            
            documento.setCatProducto(JOptionPane.showInputDialog("Ingrese la categoria del producto"));
            documento.setNomProducto(JOptionPane.showInputDialog("Ingrese el nombre del producto"));
            documento.setCostoProducto(Double.parseDouble(JOptionPane.showInputDialog("Ingrese el precio del Producto")));
            doc.add(documento);
            newCompra = this.validarOtroProducto();
            
        }while(newCompra);
        
        System.out.println("Usted Compro los siguientes productos:");
        doc.forEach(c->{
            System.out.println("Producto: " + c.getCatProducto() + " " + c.getNomProducto() + " " + c.getCostoProducto());
        });
        
        docHerencia.setTipoDocumento((String) JOptionPane.showInputDialog(null, "Que documento desea brindar",
                                    "Seleccione Documento a Emitir", JOptionPane.QUESTION_MESSAGE, null, 
                                    new Object[]{"Factura","Boleta"}, "Factura"));
        
        JOptionPane.showMessageDialog(null, "Documento a imprimir es: " + docHerencia.getTipoDocumento());
        
    }
    
    private boolean validarOtroProducto(){
        
        int  confirm =   JOptionPane.showConfirmDialog(null, "¿Desea Agregar otra producto?");
        
        if(confirm != 0){
            return false;
        }
        
        return true;
    }
    
    
}
