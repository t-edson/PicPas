
package com.cibertec.enunciado.pregunta4;

public class EnunciadoExecution {
    
    
    public static void main(String[] args) {
        
        VentaService vs = new VentaService();
        
        vs.startVenta();
        
    }
    
    
}
