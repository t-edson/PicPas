
package pregunta3;

import javax.swing.JOptionPane;

public class Promedio {

    public static void main(String[] args) {

        String valor1 = "true";
        double nota=0.0 , acumulador = 0.0;
        int i = 0;
        
        do{
            nota = Double.parseDouble(JOptionPane.showInputDialog("Ingrese Nota"));
            acumulador = acumulador + nota;
            i ++;
            valor1 = String.valueOf(JOptionPane.showInputDialog("Desea seguir ingresando? true o false"));
        }while("true".equals(valor1));
        
        
        
        System.out.println("la suma total es:" + acumulador);
        System.out.println("el promedio es :" + (acumulador/i));
        
    }
    
}
