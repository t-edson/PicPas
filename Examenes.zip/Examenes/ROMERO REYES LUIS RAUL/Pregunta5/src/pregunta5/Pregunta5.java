
package pregunta5;

import javax.swing.JOptionPane;

public class Pregunta5 {

    public static void main(String[] args) {
        
        String fecha = "";
        String mes = "";
        fecha = JOptionPane.showInputDialog("Ingrese Fecha de nacimiento dd/mm/yyyy");
        mes = fecha.substring(3,5);

        switch(mes){
            case "01": System.out.println("es Acuario");
                     break;
            case "02": System.out.println("es Piscis");
                     break;
            case "03": System.out.println("es Aries");
                     break;  
            case "04": System.out.println("es Tauro");
                     break;  
            case "05": System.out.println("es Geminis");
                     break;  
            case "06": System.out.println("es Cancer");
                     break;  
            case "07": System.out.println("es Leo");
                     break;  
            case "08": System.out.println("es Virgo");
                     break;  
            case "09": System.out.println("es Libra");
                     break;  
            case "10": System.out.println("es Escorpio");
                     break;  
            case "11": System.out.println("es Sagitario");
                     break;    
            case "12": System.out.println("es Capricornio");
                     break; 
            default:
                    System.out.println("digitar nuevamente la fecha");
                    break;
        }
        
        
    }
    
}
