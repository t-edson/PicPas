
package pregunta4;

import javax.swing.JOptionPane;

public class UsoDocumento {

    public static void main(String[] args) {
        
        String valor = JOptionPane.showInputDialog("Ingrese Boleta o Factura");

        switch(valor){
            case "Boleta": Documento midocumento = new Boleta();
                           System.out.println(midocumento.dameDocumento("Luis", 300, "Boleta", "27/04/2019"));
                           break;
            case "Factura": Documento midocumento2 = new Factura();
                            System.out.println(midocumento2.dameDocumento("Maria", 1000, "Factura", "01/12/2018")); 
            
            default:
                    System.out.println("es otro");
                    break;
        }

    }
    
}
