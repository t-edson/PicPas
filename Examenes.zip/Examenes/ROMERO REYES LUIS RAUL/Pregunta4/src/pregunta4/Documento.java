
package pregunta4;

public abstract class Documento {
    
    String nombre;
    int monto;
    String tipo;
    String fecha;
    
    public abstract String dameDocumento(String nombre, int monto, String tipo, String fecha);
    
}
