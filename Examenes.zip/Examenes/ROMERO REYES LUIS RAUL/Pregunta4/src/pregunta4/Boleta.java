
package pregunta4;

public class Boleta extends Documento{
    
    @Override
    public String dameDocumento(String nombre, int monto, String tipo, String fecha) {
        return "Documento tipo: "+tipo+ " perteneciente a "+nombre+ " con monto "+monto+" para la fecha "+fecha;
    }
    
}
