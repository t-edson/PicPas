package constructor;

public class Constructor {

    public static void main(String[] args) {
        
        Articulo a = new Articulo("Gaseosa",4);
        String nombre = a.getNombre();
        Double precio = a.getPrecio();
        a.setPrecio(5.5);
        
        System.out.println("Nombre: " + a.getNombre());
        System.out.println("Precio: " + a.getPrecio());
        
    }
    
}
