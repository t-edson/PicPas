package zodiaco;

import java.util.Scanner;

public class Zodiaco {
    public static void main(String[] args) {
        
        Scanner leer =  new Scanner(System.in);
        int dia;
        int mes;
        
        System.out.print("ingrese dia de nacimiento:");
        dia = leer.nextInt();
        System.out.print("ingrese mes de nacimiento:");
        mes = leer.nextInt();
        
        switch (mes) {
            case 1:
                System.out.println("Su signo es: Acuario");
                break;
            case 2:
                System.out.println("Su signo es: Piscis");
                break;
            case 3:
                System.out.println("Su signo es: Aries");
                break;
                
            case 4:
                System.out.println("Su signo es: Tauro");
                break;
            case 5:
                System.out.println("Su signo es: Geminis");
                break;
                
            case 6:
                System.out.println("Su signo es: Cancer");
                break;
            case 7:
                System.out.println("Su signo es: Leo");
                break;
                
            case 8:
                System.out.println("Su signo es: Virgo");
                break;
            case 9:
                System.out.println("Su signo es: Libra");
                break;
                
            case 10:
                System.out.println("Su signo es: Escorpio");
                break;
            case 11:
                System.out.println("Su signo es: Sagitario");
                break;
            case 12:
                System.out.println("Su signo es: Capricornio");
                break;
            
        }
    }
    
}
