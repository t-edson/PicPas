package preg04_luisgarcia;
public class Producto {
    
}
