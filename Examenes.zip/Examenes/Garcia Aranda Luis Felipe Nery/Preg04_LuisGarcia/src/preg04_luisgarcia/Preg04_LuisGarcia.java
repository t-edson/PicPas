package preg04_luisgarcia;

import java.util.Scanner;

public class Preg04_LuisGarcia {
    public static void main(String[] args) {
        boolean rpta;
        DetVenta det = new DetVenta();
        det.setProducto (new Producto());
        System.out.println("Tipo de Documento");
        Scanner scan = new Scanner (System.in);
        rpta = scan.nextBoolean();
        if (rpta){
            BoletaDoc boleta = new BoletaDoc();
            boleta.setDetVenta(det);
            boleta.calculaPagoTotal();
            }
        else {
            FacturaDoc factura = new FacturaDoc();
            factura.setDetVenta(det);
            factura.calculaPagoTotal();
        }
    }
}
