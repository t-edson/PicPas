package preg02_luisgarcia;
public class Main {
    public static void main(String[] args) {
        Persona p1 = new Persona ("Luis Garcia Aranda", 100);
        p1.mostrarDatos();
    }
}
