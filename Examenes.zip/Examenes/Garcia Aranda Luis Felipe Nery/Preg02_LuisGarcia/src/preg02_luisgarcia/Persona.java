
package preg02_luisgarcia;

public class Persona {
    
//Atributos
    String nombre;
    int edad;
    
    //Método Constructor
    public Persona (String nombre, int edad){
        this.nombre = nombre;
        this.edad = edad;
    }
    
    //metodo
    public void mostrarDatos () {
        System.out.println("El nombre es: " + nombre);
        System.out.println("La edad es: " + edad);
    } 
    
}
   
  