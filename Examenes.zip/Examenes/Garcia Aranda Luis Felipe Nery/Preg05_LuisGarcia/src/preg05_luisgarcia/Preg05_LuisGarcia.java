
package preg05_luisgarcia;

import java.util.Scanner;

public class Preg05_LuisGarcia {
    public static void main(String[] args) {
        
        int dia;
        int mes;
        Scanner reader= new Scanner (System.in);
        System.out.println("Que día naciste:");
        dia=reader.nextInt();
        System.out.println("Que mes naciste:");
        mes = reader.nextInt();
        switch(mes){
            case 1:
                //Enero
                if (dia>=21)
                    System.out.println("Acuario");
                else
                    System.out.println("Capricornio");
                break;
            case 2:
                //febrero
                if (dia>=19)
                    System.out.println("Piscis");
                else
                    System.out.println("Acuario");
                break;
            case 3:
                //Marzo
                if (dia>=21)
                    System.out.println("Aries");
                else
                    System.out.println("Piscis");
                break;
            case 4:
                //Abril
                if (dia>=22)
                    System.out.println("Tauro");
                else 
                    System.out.println("Aries");
                break;
            case 5:
                //Mayo
                if (dia>=22)
                    System.out.println("Géminis");
                else
                    System.out.println("Tauro");
                break;
            case 6:
                //Junio
                if (dia>=23)
                    System.out.println("Cáncer");
                else
                    System.out.println("Géminis");
                break;
            case 7:
                //Julio
                if (dia>=24)
                    System.out.println("Leo");
                else
                    System.out.println("Cáncer");
                break;
            case 8:
                //Agosto
                if (dia>=25)
                    System.out.println("Virgo");
                else
                    System.out.println("Leo");
                break;
            case 9:
                //Setiembre
                if (dia>=25)
                    System.out.println("Libra");
                else
                    System.out.println("Virgo");
                break;
            case 10:
                //Octubre
                if (dia>=24)
                    System.out.println("Escorpio");
                else
                    System.out.println("Libra");
                break;
            case 11:
                //Noviembre
                if (dia>=23)
                    System.out.println("Sagitario");
                else
                    System.out.println("Escorpio");
                break;
            case 12:
                //Diciembre
                if (dia>=23)
                    System.out.println("Capricornio");
                else
                    System.out.println("Sagitario");

        }
    }
}






