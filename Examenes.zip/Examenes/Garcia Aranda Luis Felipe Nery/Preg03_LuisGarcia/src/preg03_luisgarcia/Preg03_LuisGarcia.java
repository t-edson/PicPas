package preg03_luisgarcia;

import java.util.Scanner;

public class Preg03_LuisGarcia {
    
    public static void main(String[] args) {
        int cantNotas = 3;
        int sumNotas = 0;
        int x = 1;
        System.out.println("Cantidad de notas: ");
        Scanner notas = new Scanner (System.in);
        cantNotas = notas.nextInt();
        
        while (cantNotas>=x){
        Scanner scan = new Scanner(System.in);
            System.out.print("Ingresar Nota " + x + ": ");
            sumNotas=scan.nextInt() + sumNotas;
            x++;
        }
        System.out.println("Total Sumatoria de Notas: " + sumNotas/cantNotas);
    }
}
        
        
        
        
 


        
       