package expregunta04;
public class Documento {
    public String nombre;
    public int edad;
    public int dni;

    public void MostrarNombre() {
        System.out.println("Me llamo  : " + nombre);
    }
}
