package expregunta04;
public class Factura extends Documento{
         @Override
         public void MostrarNombre() {
        System.out.println("Usted elegio pagar con Factura");
    }   
}
