package expregunta04;

import java.util.Scanner;

public class ExPregunta04 {

    public static void main(String[] args) {

        int tipoDocumento;

        Scanner teclado = new Scanner(System.in);
        System.out.print("Ingrese con que tipo de documentyo a pagar (1 Boleta, 2 Factura: ");
        try {
        tipoDocumento = teclado.nextInt();
        switch (tipoDocumento) {
            case 1:
                Boleta b = new Boleta();
                b.MostrarNombre();
                break;
            case 2:
                Factura f = new Factura();
                f.MostrarNombre();
                break;
        }
        
        } catch (Exception e) {
            System.out.println("Se ha producido una exception con mensaje: " + e.toString());
        }
        
        
        

    }

}
