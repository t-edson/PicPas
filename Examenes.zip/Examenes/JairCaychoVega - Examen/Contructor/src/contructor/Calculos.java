package contructor;
public class Calculos {

    public void Calculos(int a) {
        ///  codigogos
    }
}
