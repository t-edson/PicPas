package expregunta07;

import java.util.Scanner;

public class ExPregunta07 {

    public static void main(String[] args) {

        int mes;
        boolean lbootean = false;

        System.out.println("Signo Zodiacal");
        System.out.println("==============");
        System.out.println("");

        do {

            Scanner teclado = new Scanner(System.in);
            System.out.print("Ingrese mes de tu fecha de nacimiento : ");
            try {
                mes = teclado.nextInt();

                switch (mes) {
                    case 1:
                        System.out.println("Su signo es ACUARIO:  ");
                        break;
                    case 2:
                        System.out.println("Su signo es : PISIS ");
                        break;
                    case 3:
                        System.out.println("Su signo es : ARIES  ");
                        break;
                    case 4:
                        System.out.println("Su signo es : TAURO  ");
                        break;
                    case 5:
                        System.out.println("Su signo es : GEMINNIS  ");
                        break;
                    case 6:
                        System.out.println("Su signo es : CANCER ");
                        break;
                    case 7:
                        System.out.println("Su signo es : LEO ");
                        break;
                    case 8:
                        System.out.println("Su signo es : VIRGO ");
                        break;
                    case 9:
                        System.out.println("Su signo es : LIBRA");
                        break;
                    case 10:
                        System.out.println("Su signo es : ESCORPIO ");
                        break;
                    case 11:
                        System.out.println("Su signo es : SAGITARIO ");
                        break;
                    case 12:
                        System.out.println("Su signo es : CAPRICORNIO ");
                        break;
                }
                lbootean = false;

            } catch (Exception e) {
                System.out.println("Se ha producido una exception con mensaje: " + e.toString());
                System.out.println("");
                System.out.println("Ingrese un numero de mes incorrecto, vuelve a intentar");
                System.out.println("");
                lbootean = true;
            }

        } while (lbootean == true);

    }

}
