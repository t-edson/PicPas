package expregunta03;
import java.util.Scanner;
public class ExPregunta03 {
    public static void main(String[] args) {
        int n = 1;
        int nota;
        int acum = 0;
        double prom = 0.0;
        // Creo el teclado
        System.out.println("Promedio");

        Scanner teclado = new Scanner(System.in);
        while (n <= 3) {

            System.out.print("Ingrese nota : ");
            nota = teclado.nextInt();
            acum = acum + nota;
            n += 1;
        }
        prom = acum / 3;

        System.out.println("Promedio de nota es : " + prom);
    }
}
