package expregunta05;
import java.security.Timestamp;
import java.time.LocalDate;
import java.time.Month;
import java.util.Scanner;
public class ExPregunta05 {
    public static void main(String[] args) {
        int mes;
        Timestamp fecha;
        //Month mes = LocalDate.now().getMonth();
        System.out.println("Signo Zodiacal");
        System.out.println("==============");
        System.out.println("");
        
        Scanner teclado = new Scanner(System.in);
        System.out.print("Ingrese mes de tu fecha de nacimiento : ");
        mes = teclado.nextInt();
        
         /*  Scanner teclado2 = new Scanner(System.in);
        System.out.print("Ingrese mes de tu fecha de nacimiento : ");
        fecha = teclado2.next();
         */     
        
        switch (mes) {
            case 1:
                System.out.println("Su signo es ACUARIO:  ");
                break;
            case 2:
                System.out.println("Su signo es : PISIS ");
                break;
            case 3:
                System.out.println("Su signo es : ARIES  ");
                break;
            case 4:
                System.out.println("Su signo es : TAURO  ");
                break;
            case 5:
                System.out.println("Su signo es : GEMINNIS  ");
                break;
            case 6:
                System.out.println("Su signo es : CANCER ");
                break;
            case 7:
                System.out.println("Su signo es : LEO ");
                break;
            case 8:
                System.out.println("Su signo es : VIRGO ");
                break;
            case 9:
                System.out.println("Su signo es : LIBRA");
                break;
            case 10:
                System.out.println("Su signo es : ESCORPIO ");
                break;
            case 11:
                System.out.println("Su signo es : SAGITARIO ");
                break;
            case 12:
                System.out.println("Su signo es : CAPRICORNIO ");
                break;
        }
    }
}
